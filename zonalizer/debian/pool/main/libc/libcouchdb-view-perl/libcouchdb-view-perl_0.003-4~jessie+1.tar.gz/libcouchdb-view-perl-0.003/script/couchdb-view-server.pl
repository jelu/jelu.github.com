#!/usr/bin/perl

use CouchDB::View::Server;
CouchDB::View::Server->run;
